// mutation-types.js -> mutations.js -> getters.js -> actions.js
export const GET_TESTDATA = "GET_TESTDATA"

// 주로 컴포넌트에서 state의 값을 가져갈 때에 대한 정의를 담고있는 파일
export const testData = state => state.testData